﻿namespace SistemaVenta.AplicacionWeb.Models.ViewModels
{
    public class VMVentasSemana
    {
        public string? Fecha { get; set; }
        public string? Total { get; set; }
    }
}
